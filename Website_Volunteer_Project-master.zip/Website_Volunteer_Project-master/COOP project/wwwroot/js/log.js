﻿function login()
{
    const userName = document.getElementById("userName");
    const passWord = document.getElementById("passWord");
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function ()
    {
        xhttp.open("POST","../Controllers/LoginController.cs")
    };
}