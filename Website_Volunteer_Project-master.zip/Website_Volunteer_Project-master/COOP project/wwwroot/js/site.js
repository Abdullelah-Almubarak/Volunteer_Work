﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
//window.onscroll = function() {myFunction()};

//// Get the navbar
//var navbar = document.getElementById("nv");

//// Get the offset position of the navbar
//var sticky = navbar.offsetTop;

//// Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
//function myFunction() {
//  if (window.pageYOffset >= stick) {
//    navbar.classList.add("stick")
//  } else {
//    navbar.classList.remove("sticky");
//  }
//}