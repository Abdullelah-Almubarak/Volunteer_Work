﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace COOP_project.Migrations
{
    public partial class allguidCoop : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
